package com.example.pekerjaan.ui.jobs3

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.pekerjaan.R
import com.example.pekerjaan.pekerjaan
import com.example.pekerjaan.pekerjaanDetails
import com.example.pekerjaan.pekerjaanViewModel
import com.example.pekerjaan.ui.jobs3.Jobs3Adapter

class Jobs3Adapter (
    private  val context: Context,
    private val dataset: List<pekerjaan>
): RecyclerView.Adapter<Jobs3Adapter.Jobs3ViewHolder> () {

    private val viewModel = pekerjaanViewModel()
    class Jobs3ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val jobsImg: ImageView = view.findViewById(R.id.pekerjaan_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Jobs3Adapter.Jobs3ViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_jobs, parent, false)
        return Jobs3Adapter.Jobs3ViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(
        holder: Jobs3Adapter.Jobs3ViewHolder,
        position: Int,
    ){
        val jobs3Data = dataset[position]
        holder.jobsImg.setImageResource(jobs3Data.imageResourceId)

        holder.itemView.setOnClickListener{
            viewModel.setPekerjaan(jobs3Data, context)

            val intent = Intent(context, pekerjaanDetails::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)
        }
    }
}