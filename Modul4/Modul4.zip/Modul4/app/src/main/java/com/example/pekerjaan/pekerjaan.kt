package com.example.pekerjaan

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class pekerjaan (
    @DrawableRes val imageResourceId: Int,
    @StringRes val name: Int,
    @StringRes val desc: Int
)

