package com.example.pekerjaan

import androidx.lifecycle.ViewModel

class data : ViewModel() {
    fun jobs(): List<pekerjaan> {
        return listOf(
            pekerjaan(
                R.drawable.p1, R.string.pekerjaan1, R.string.deskripsi1
            ),
            pekerjaan(
                R.drawable.p2, R.string.pekerjaan2, R.string.deskripsi2
            ),
            pekerjaan(
                R.drawable.p3, R.string.pekerjaan3, R.string.deskripsi3
            ),
            pekerjaan(
                R.drawable.p4, R.string.pekerjaan4, R.string.deskripsi4
            ),
            pekerjaan(
                R.drawable.p5, R.string.pekerjaan5, R.string.deskripsi5
            ),
            pekerjaan(
                R.drawable.p6, R.string.pekerjaan6, R.string.deskripsi6
            ),
        )

    }
    fun jobs2(): List<pekerjaan>{
        return listOf(
            pekerjaan(
                R.drawable.p7,R.string.pekerjaan7, R.string.deskripsi7
            ),
            pekerjaan(
                R.drawable.p8, R.string.pekerjaan8, R.string.deskripsi8
            ),
            pekerjaan(
                R.drawable.p9, R.string.pekerjaan9, R.string.deskripsi9
            ),
            pekerjaan(
                R.drawable.p10, R.string.pekerjaan10, R.string.deskripsi10
            ),
            pekerjaan(
                R.drawable.p11, R.string.pekerjaan11, R.string.deskripsi11
            ),
            pekerjaan(
                R.drawable.p12, R.string.pekerjaan12, R.string.deskripsi12
            ),
        )
    }

    fun jobs3(): List<pekerjaan>{
        return listOf(
            pekerjaan(
                R.drawable.p13,R.string.pekerjaan13, R.string.deskripsi13
            ),
            pekerjaan(
                R.drawable.p14, R.string.pekerjaan14, R.string.deskripsi14
            ),
            pekerjaan(
                R.drawable.p15, R.string.pekerjaan15, R.string.deskripsi15
            ),
            pekerjaan(
                R.drawable.p16, R.string.pekerjaan16, R.string.deskripsi16
            ),
            pekerjaan(
                R.drawable.p17, R.string.pekerjaan17, R.string.deskripsi17
            ),
            pekerjaan(
                R.drawable.p18, R.string.pekerjaan18, R.string.deskripsi18
            ),
        )
    }
}