package com.example.pekerjaan.ui.jobs

import android.content.Context
import android.content.Intent
import android.service.autofill.Dataset
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.pekerjaan.*

class JobsAdapter (
    private  val context: Context,
    private val dataset: List<pekerjaan>
    ): RecyclerView.Adapter<JobsAdapter.JobsViewHolder> () {

        private val viewModel = pekerjaanViewModel()
    class JobsViewHolder(view: View): RecyclerView.ViewHolder(view){
        val jobsImg: ImageView = view.findViewById(R.id.pekerjaan_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobsAdapter.JobsViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_jobs, parent, false)
        return JobsAdapter.JobsViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(
        holder: JobsAdapter.JobsViewHolder,
        position: Int,
    ){
        val jobsData = dataset[position]
        holder.jobsImg.setImageResource(jobsData.imageResourceId)

        holder.itemView.setOnClickListener{
            viewModel.setPekerjaan(jobsData, context)

            val intent = Intent(context, pekerjaanDetails::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)
        }
    }
    }