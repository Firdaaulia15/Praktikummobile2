package com.example.pekerjaan.ui.jobs3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pekerjaan.R
import com.example.pekerjaan.data
import com.example.pekerjaan.databinding.FragmentJobsItemBinding
import com.example.pekerjaan.ui.jobs3.Jobs3Adapter

class Jobs3Fragment : Fragment(R.layout.fragment_jobs_item){
    private var _binding: FragmentJobsItemBinding? = null
    private val binding get() = _binding!!
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentJobsItemBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        recyclerView = binding.recyclerView
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = Jobs3Adapter(requireContext(), data().jobs3())

    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}